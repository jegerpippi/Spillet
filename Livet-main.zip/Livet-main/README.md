# Livet
... slik jeg ser det, er et spill. 

Regler: 
-Før hovedreglen legger likevel Pippi til at han kjenner til Conway's 'Game of Life', hvilket er et nullspiller-spill.
Som hovedregel settes det her opp at alle spill bør ha minst 0.1 i mulig gevinst.

(For å unngå null-sum-spill, selv om så skulle vært i et null-spiller-spill)

Men

--Kan vi enes om at livet vi lever, ikke er et spill hvor spillerne er mindre enn 0.1?

Jeg har ikke lyst å sette hverken nummer eller ord her egentlig. 
For uansett hva jeg skriver, vil det aldri kunne stemme med alle. 

Så...

'gevinst' == 'pluss' og/eller 'minus'

Blir det riktig slik?

Jeg vet ikke...

Selv er det nok slik jeg ser på livet tror jeg.. At uansett hvordan det oppleves, vondt eller godt, så velger jeg å fokusere 'leves'-biten. 
Så om det opp-leves, ned-leves, godt-leves eller vondt-leves, så har jeg som personlig grunnverdi, at jeg liker å leve.

Kanskje er det mange som aldri vil tro på meg når jeg forteller dem.
(Vet ikke engang om noen vil være i stand til å forstå vitsen i forrige setning, og at det ikke er en vrang, men en rett.)
Men jeg velger altså, selv om mange ikke tror på meg når jeg sier det, å se fremover. 

Sint har jeg vært mye. Og på mange.
På noen mer enn andre.
'Urettferdig!' - Vil nok kanskje mange si. 

Ja. Selvsagt. Det er jeg også det!
(Urettferdig altså).

Men fra mitt egoistiske, lille hode, vil det alltid være farlig med spill hvor noen vinner alt, og andre taper alt. 
Fordi det oppstår nesten umulig tilstander av slikt. 

Island var lenge plaget med det jeg tenker på. Noen har garantert hørt om 'blodhevn'. 
Ville knapt vært et menneske igjen der i dag. På den lille øya. Dersom de hadde fortsatt med 'øye-for-tann, bror-for-venn, steining-for-korsting-i-glasshus'.

Det gikk an på Island. Noen var så urettferdige, at de valgte å ikke gjøre hevn. Heldigvis?
Tror det. Tror også at mange ble veldig sinte. Og redde. Og forvirret.

Jeg tror mange forventer at jeg skal gjøre de vondeste og sykeste ting mot seg. 
Det er i hvert fall slik jeg opplever å ha overlevd den siste tiden.

Noen ytterst få personer har nok også fått oppleve både sinne og galskap fra meg.
F.eks ble jeg nødt å la noen gå lenge i tro at jeg skulle tenne på leiligheten dems.

Så langt dro jeg det, at jeg brukte både flammer, hærverk og vold.
Jeg måtte dessverre. Tror jeg. 

Men kanskje klarte jeg dermed å snu litt på bjelken, eller flisa. Om det er min egen eller min brors skal ikke jeg henge meg opp i;
Uansett ble det fremtvunget en situasjon som ikke kan kalles annet enn 'umulig'.

Likevel sitter jeg her. Ensom, sliten, sulten og med lyst på røyk.
I en leilighet jeg har ramponert: 
Fordi jeg ikke får lov å være alene, eller trygg, eller noe som helst.

Men politiet dro sin vei. Rørte hverken meg, speeden, røyken eller hasjen min.
(Det siste hadde jeg ikke engang. Gikk tom for lenge siden. Men vil gjerne ha!)

Nesten uvirkelig å ha opplevd, at hverken speeden på bordet eller kniven i veggen ble nevnt engang.
De ville bare sjekke en bekymring de hadde fått høre om. Heldigvis stemte den ikke.
(Jo og nei vil vi nok alltid og aldri være enige om på den siste der.)
